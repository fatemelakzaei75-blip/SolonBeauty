using System.Security.Cryptography;

namespace WebApiSolon.Services;

/// <summary>نتیجه ذخیره یک فایل</summary>
public record StoredFile(string FileName, string RelativeUrl, string Hash, long Size, bool AlreadyExisted);

/// <summary>
/// ذخیره تصاویر در ریشه WebApi (پوشه wwwroot/uploads) با نام گذاری هش SHA-256.
/// ساختار پوشه: uploads/{بخش}/{سال}/{ماه}/{hash}{پسوند}
/// فایل تکراری دوباره ذخیره نمی شود (نام هش یکسان = محتوای یکسان).
/// </summary>
public class FileStorageService
{
    private readonly IWebHostEnvironment _env;
    private readonly ILogger<FileStorageService> _logger;

    public const string RootFolder = "uploads";
    private const long MaxBytes = 5 * 1024 * 1024;   // ۵ مگابایت

    private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png", ".webp", ".gif" };
    private static readonly string[] AllowedContentTypes = { "image/jpeg", "image/png", "image/webp", "image/gif" };

    public FileStorageService(IWebHostEnvironment env, ILogger<FileStorageService> logger)
    {
        _env = env; _logger = logger;
    }

    private string WebRoot => string.IsNullOrWhiteSpace(_env.WebRootPath)
        ? Path.Combine(_env.ContentRootPath, "wwwroot")
        : _env.WebRootPath;

    /// <summary>اعتبارسنجی فایل ورودی</summary>
    public (bool Ok, string Message) Validate(IFormFile file)
    {
        if (file is null || file.Length == 0) return (false, "فایلی ارسال نشده است");
        if (file.Length > MaxBytes) return (false, "حجم تصویر نباید بیشتر از ۵ مگابایت باشد");

        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!AllowedExtensions.Contains(ext)) return (false, "فرمت مجاز: jpg, jpeg, png, webp, gif");
        if (!AllowedContentTypes.Contains(file.ContentType.ToLowerInvariant())) return (false, "نوع فایل تصویری معتبر نیست");

        return (true, string.Empty);
    }

    /// <summary>ذخیره فایل با نام هش SHA-256 و برگرداندن آدرس نسبی</summary>
    public async Task<StoredFile> SaveAsync(IFormFile file, string section = "portfolio", CancellationToken ct = default)
    {
        section = SanitizeSection(section);

        // ۱) محاسبه هش محتوا
        await using var stream = file.OpenReadStream();
        using var sha = SHA256.Create();
        var hashBytes = await sha.ComputeHashAsync(stream, ct);
        var hash = Convert.ToHexString(hashBytes).ToLowerInvariant();

        // ۲) مسیر پوشه بندی شده بر اساس سال/ماه
        var now = DateTime.UtcNow;
        var relativeDir = Path.Combine(RootFolder, section, now.ToString("yyyy"), now.ToString("MM"));
        var absoluteDir = Path.Combine(WebRoot, relativeDir);
        Directory.CreateDirectory(absoluteDir);

        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        var fileName = $"{hash}{ext}";
        var absolutePath = Path.Combine(absoluteDir, fileName);
        var relativeUrl = "/" + Path.Combine(relativeDir, fileName).Replace('\\', '/');

        // ۳) اگر فایلی با همین هش موجود باشد، دوباره نوشته نمی شود
        if (File.Exists(absolutePath))
        {
            _logger.LogInformation("تصویر تکراری بود و از نسخه موجود استفاده شد: {File}", relativeUrl);
            return new StoredFile(fileName, relativeUrl, hash, new FileInfo(absolutePath).Length, true);
        }

        stream.Position = 0;
        await using (var target = File.Create(absolutePath))
            await stream.CopyToAsync(target, ct);

        return new StoredFile(fileName, relativeUrl, hash, file.Length, false);
    }

    /// <summary>حذف فایل ذخیره شده بر اساس آدرس نسبی</summary>
    public bool Delete(string relativeUrl)
    {
        try
        {
            var clean = relativeUrl.TrimStart('/', '\\');
            if (!clean.StartsWith(RootFolder, StringComparison.OrdinalIgnoreCase)) return false;

            var path = Path.Combine(WebRoot, clean.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(path)) return false;

            File.Delete(path);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "حذف فایل ناموفق بود: {Url}", relativeUrl);
            return false;
        }
    }

    /// <summary>فهرست فایل های یک بخش</summary>
    public List<string> List(string section = "portfolio")
    {
        section = SanitizeSection(section);
        var dir = Path.Combine(WebRoot, RootFolder, section);
        if (!Directory.Exists(dir)) return new List<string>();

        return Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories)
            .Select(f => "/" + Path.GetRelativePath(WebRoot, f).Replace('\\', '/'))
            .OrderByDescending(f => f)
            .ToList();
    }

    /// <summary>جلوگیری از Path Traversal در نام بخش</summary>
    private static string SanitizeSection(string section)
    {
        if (string.IsNullOrWhiteSpace(section)) return "portfolio";
        var clean = new string(section.Where(c => char.IsLetterOrDigit(c) || c is '-' or '_').ToArray());
        return string.IsNullOrEmpty(clean) ? "portfolio" : clean.ToLowerInvariant();
    }
}

using System.Text;
using DataCore.Services;
using DataLayer.Context;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using WebApiSolon.Services;

var builder = WebApplication.CreateBuilder(args);

// در حالت توسعه می توان با UseInMemoryDatabase=true بدون SQL Server کار کرد
var useInMemory = builder.Configuration.GetValue<bool>("UseInMemoryDatabase");
builder.Services.AddDbContext<DatabaseContext>(options =>
{
    if (useInMemory) options.UseInMemoryDatabase("SolonSalonDev");
    else options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
});

builder.Services.AddScoped<JwtTokenService>();
builder.Services.AddScoped<FileStorageService>();

// سرویس های لایه DataCore (پیاده سازی اینترفیس ها روی EF Core)
builder.Services.AddDataCoreServices();

// ---------- احراز هویت JWT ----------
var jwtSection = builder.Configuration.GetSection("Jwt");
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwtSection["Issuer"],
            ValidAudience = jwtSection["Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSection["Key"]!)),
            ClockSkew = TimeSpan.FromMinutes(1)
        };
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", p => p.RequireRole("Admin"));
    options.AddPolicy("PersonnelOnly", p => p.RequireRole("Personnel", "Admin"));
    options.AddPolicy("CustomerOnly", p => p.RequireRole("Customer", "Admin"));
});

// ---------- CORS برای کلاینت Blazor ----------
builder.Services.AddCors(o => o.AddPolicy("BlazorClient", p =>
    p.SetIsOriginAllowed(_ => true).AllowAnyHeader().AllowAnyMethod()));

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Solon Salon API", Version = "v1" });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "توکن JWT را به صورت 'Bearer {token}' وارد کنید",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

// ساخت/به‌روزرسانی خودکار دیتابیس (در نبود SQL Server فقط لاگ می‌شود)
using (var scope = app.Services.CreateScope())
{
    try
    {
        var db = scope.ServiceProvider.GetRequiredService<DatabaseContext>();
        if (useInMemory)
        {
            db.Database.EnsureCreated();
            DevDataSeeder.Seed(db);
        }
        else db.Database.Migrate();
    }
    catch (Exception ex)
    {
        app.Logger.LogError(ex, "Database migration failed.");
    }
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// سرو فایل های آپلود شده از ریشه API (wwwroot/uploads/...)
Directory.CreateDirectory(Path.Combine(app.Environment.ContentRootPath, "wwwroot", FileStorageService.RootFolder));
app.UseStaticFiles();

app.UseCors("BlazorClient");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();

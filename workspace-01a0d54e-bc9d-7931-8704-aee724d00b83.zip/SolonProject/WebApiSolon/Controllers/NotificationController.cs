using System;
using System.Linq;
using System.Security.Claims;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiSolon.Models;

namespace WebApiSolon.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class NotificationController : ControllerBase
{
    private readonly DatabaseContext _db;
    public NotificationController(DatabaseContext db) => _db = db;

    [HttpGet]
    public ActionResult GetMyNotifications()
    {
        var role = User.IsInRole("Admin") ? "Admin" : User.IsInRole("Personnel") ? "Personnel" : "Customer";
        var list = _db.Tbl_Notification
            .Where(n => !n.IsDelete && (n.TargetRole == role || n.TargetRole == "All"))
            .OrderByDescending(n => n.RegisterData)
            .Take(50)
            .ToList();
        return Ok(list);
    }

    [HttpPatch("{tc:guid}/read")]
    public ActionResult MarkAsRead(Guid tc)
    {
        var item = _db.Tbl_Notification.FirstOrDefault(x => x.Tc == tc && !x.IsDelete);
        if (item is null) return NotFound(new ApiResult { Message = "اعلان یافت نشد." });
        item.IsRead = true;
        _db.SaveChanges();
        return Ok(new ApiResult { Success = true });
    }

    [HttpPost("mark-all-read")]
    public ActionResult MarkAllAsRead()
    {
        var role = User.IsInRole("Admin") ? "Admin" : User.IsInRole("Personnel") ? "Personnel" : "Customer";
        var items = _db.Tbl_Notification.Where(n => !n.IsDelete && (n.TargetRole == role || n.TargetRole == "All") && !n.IsRead).ToList();
        foreach (var it in items) it.IsRead = true;
        _db.SaveChanges();
        return Ok(new ApiResult { Success = true });
    }
}

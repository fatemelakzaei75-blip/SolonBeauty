using DataLayer.Context;
using DataLayer.Entity.BaseEntity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiSolon.Models;

namespace WebApiSolon.Controllers;

/// <summary>
/// کنترلر پایه CRUD برای همه موجودیت های مشتق از Tbl_BaseEntity.
/// حذف به صورت منطقی (IsDelete) انجام می شود.
/// </summary>
[ApiController]
[Authorize(Roles = "Admin")]
public abstract class BaseCrudController<TEntity> : ControllerBase where TEntity : Tbl_BaseEntity
{
    protected readonly DatabaseContext Db;
    protected BaseCrudController(DatabaseContext db) => Db = db;

    protected DbSet<TEntity> Set => Db.Set<TEntity>();

    /// <summary>فهرست رکوردهای حذف نشده</summary>
    [HttpGet]
    public virtual async Task<ActionResult<List<TEntity>>> GetAll()
        => Ok(await Set.AsNoTracking().Where(x => !x.IsDelete).ToListAsync());

    /// <summary>دریافت یک رکورد با TC</summary>
    [HttpGet("{tc:guid}")]
    public virtual async Task<ActionResult<TEntity>> Get(Guid tc)
    {
        var item = await Set.AsNoTracking().FirstOrDefaultAsync(x => x.Tc == tc && !x.IsDelete);
        return item is null ? NotFound(new ApiResult { Message = "رکورد یافت نشد" }) : Ok(item);
    }

    /// <summary>ثبت رکورد جدید</summary>
    [HttpPost]
    public virtual async Task<ActionResult<TEntity>> Create([FromBody] TEntity entity)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        entity.ID = 0;
        if (entity.Tc == Guid.Empty) entity.Tc = Guid.NewGuid();
        entity.RegisterData = DateTime.Now;
        entity.IsDelete = false;
        Set.Add(entity);
        await Db.SaveChangesAsync();
        return Ok(entity);
    }

    /// <summary>ویرایش رکورد</summary>
    [HttpPut("{tc:guid}")]
    public virtual async Task<ActionResult<TEntity>> Update(Guid tc, [FromBody] TEntity entity)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        var current = await Set.FirstOrDefaultAsync(x => x.Tc == tc && !x.IsDelete);
        if (current is null) return NotFound(new ApiResult { Message = "رکورد یافت نشد" });

        entity.ID = current.ID;
        entity.Tc = current.Tc;
        entity.RegisterData = current.RegisterData;
        Db.Entry(current).CurrentValues.SetValues(entity);
        await Db.SaveChangesAsync();
        return Ok(current);
    }

    /// <summary>حذف منطقی رکورد</summary>
    [HttpDelete("{tc:guid}")]
    public virtual async Task<ActionResult<ApiResult>> Delete(Guid tc)
    {
        var current = await Set.FirstOrDefaultAsync(x => x.Tc == tc && !x.IsDelete);
        if (current is null) return NotFound(new ApiResult { Message = "رکورد یافت نشد" });
        current.IsDelete = true;
        current.IsActive = false;
        await Db.SaveChangesAsync();
        return Ok(new ApiResult { Success = true, Message = "رکورد حذف شد" });
    }
}

using System;
using System.Linq;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiSolon.Models;

namespace WebApiSolon.Controllers;

[ApiController]
[Route("api/[controller]")]
public class WaitingListController : ControllerBase
{
    private readonly DatabaseContext _db;
    public WaitingListController(DatabaseContext db) => _db = db;

    /// <summary>ثبت نام در لیست انتظار (بند ۱۱ سند)</summary>
    [AllowAnonymous]
    [HttpPost]
    public ActionResult<Tbl_WaitingList> Add([FromBody] Tbl_WaitingList entry)
    {
        if (string.IsNullOrWhiteSpace(entry.CustomerName) || string.IsNullOrWhiteSpace(entry.MobileNumber) || string.IsNullOrWhiteSpace(entry.ServiceName))
            return BadRequest(new ApiResult { Message = "نام، شماره موبایل و خدمت الزامی هستند." });

        entry.Tc = Guid.NewGuid();
        entry.Status = WaitingStatus.Waiting;
        entry.IsActive = true;
        entry.RegisterData = DateTime.Now;

        _db.Tbl_WaitingList.Add(entry);
        _db.SaveChanges();

        return Ok(entry);
    }

    /// <summary>لیست انتظار برای ادمین</summary>
    [Authorize(Roles = "Admin,Personnel")]
    [HttpGet]
    public ActionResult GetList()
        => Ok(_db.Tbl_WaitingList.Where(x => !x.IsDelete).OrderByDescending(x => x.RegisterData).ToList());

    /// <summary>ارسال پیام اطلاع‌رسانی باز شدن نوبت به مشتری در لیست انتظار با مهلت تأیید</summary>
    [Authorize(Roles = "Admin")]
    [HttpPost("{tc:guid}/notify")]
    public ActionResult<ApiResult> Notify(Guid tc, [FromQuery] int minutesDeadline = 60)
    {
        var item = _db.Tbl_WaitingList.FirstOrDefault(x => x.Tc == tc && !x.IsDelete);
        if (item is null) return NotFound(new ApiResult { Message = "مورد یافت نشد." });

        item.Status = WaitingStatus.Notified;
        item.NotifyDeadline = DateTime.Now.AddMinutes(minutesDeadline);
        _db.SaveChanges();

        return Ok(new ApiResult
        {
            Success = true,
            Message = $"پیامک آزادسازی نوبت با مهلت تأیید تا {item.NotifyDeadline:HH:mm} برای {item.CustomerName} ارسال شد."
        });
    }
}

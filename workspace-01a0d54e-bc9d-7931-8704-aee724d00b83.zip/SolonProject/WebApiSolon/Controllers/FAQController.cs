using System.Linq;
using DataLayer.Context;
using Microsoft.AspNetCore.Mvc;

namespace WebApiSolon.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FAQController : ControllerBase
{
    private readonly DatabaseContext _db;
    public FAQController(DatabaseContext db) => _db = db;

    [HttpGet]
    public ActionResult GetAll()
        => Ok(_db.Tbl_FAQ.Where(f => !f.IsDelete && f.IsPublished).OrderBy(f => f.OrderIndex).ToList());
}

using System;
using System.Linq;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiSolon.Models;

namespace WebApiSolon.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SalonSettingController : ControllerBase
{
    private readonly DatabaseContext _db;
    public SalonSettingController(DatabaseContext db) => _db = db;

    /// <summary>دریافت تنظیمات فعلی سالن، تم و ساعات کاری (عمومی)</summary>
    [HttpGet]
    public ActionResult<Tbl_SalonSetting> Get()
    {
        var setting = _db.Tbl_SalonSetting.FirstOrDefault(x => !x.IsDelete);
        if (setting is null)
        {
            setting = new Tbl_SalonSetting
            {
                Tc = Guid.NewGuid(),
                IsActive = true,
                RegisterData = DateTime.Now
            };
            _db.Tbl_SalonSetting.Add(setting);
            _db.SaveChanges();
        }
        return Ok(setting);
    }

    /// <summary>به‌روزرسانی تنظیمات توسط ادمین</summary>
    [Authorize(Roles = "Admin")]
    [HttpPut]
    public ActionResult<ApiResult> Update([FromBody] Tbl_SalonSetting model)
    {
        var current = _db.Tbl_SalonSetting.FirstOrDefault(x => !x.IsDelete);
        if (current is null)
        {
            model.Tc = Guid.NewGuid();
            model.IsActive = true;
            model.RegisterData = DateTime.Now;
            _db.Tbl_SalonSetting.Add(model);
        }
        else
        {
            current.SalonName = model.SalonName;
            current.SalonLatinName = model.SalonLatinName;
            current.HeroSubtitle = model.HeroSubtitle;
            current.IntroText = model.IntroText;
            current.AboutText = model.AboutText;
            current.IsSingleLineMode = model.IsSingleLineMode;
            current.ActiveLineSlug = model.ActiveLineSlug;
            current.OpeningHour = model.OpeningHour;
            current.ClosingHour = model.ClosingHour;
            current.OffHoursMessage = model.OffHoursMessage;
            current.Theme = model.Theme;
            current.PhoneLandline = model.PhoneLandline;
            current.PhoneMobile = model.PhoneMobile;
            current.Email = model.Email;
            current.Address = model.Address;
            current.WorkingHoursDisplay = model.WorkingHoursDisplay;
            current.InstagramUrl = model.InstagramUrl;
            current.TelegramUrl = model.TelegramUrl;
            current.WhatsAppUrl = model.WhatsAppUrl;
            current.DomesticSocialUrl = model.DomesticSocialUrl;
            current.HeroSliderImages = model.HeroSliderImages;
        }
        _db.SaveChanges();
        return Ok(new ApiResult { Success = true, Message = "تنظیمات سالن با موفقیت ذخیره شد." });
    }
}

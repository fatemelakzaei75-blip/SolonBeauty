using System;
using System.Collections.Generic;
using System.Security.Claims;
using DataCore.Interfaces;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiSolon.Models;

namespace WebApiSolon.Controllers;

/// <summary>ثبت و مدیریت نوبت‌ها، درگاه زرین‌پال، رزرو حضوری و استرداد وجه (بندهای ۸، ۹، ۱۰، ۱۴ و ۱۵ سند)</summary>
[ApiController]
[Route("api/[controller]")]
public class ReservationController : ControllerBase
{
    private readonly IReservationService _reservations;
    private readonly DatabaseContext _db;

    public ReservationController(IReservationService reservations, DatabaseContext db)
    {
        _reservations = reservations;
        _db = db;
    }

    private Guid CurrentTc =>
        Guid.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var g) ? g : Guid.Empty;

    private bool IsInRole(string role) => User.IsInRole(role);

    /// <summary>فهرست نوبت‌ها (مدیر: همه، پرسنل: نوبت‌های خودش، مشتری: نوبت‌های خودش)</summary>
    [Authorize]
    [HttpGet]
    public ActionResult<List<Tbl_Reservation>> GetAll()
    {
        if (IsInRole("Admin")) return Ok(_reservations.GetReservations());
        if (IsInRole("Personnel")) return Ok(_reservations.GetByPersonalTC(CurrentTc));
        return Ok(_reservations.GetByCustomerTC(CurrentTc));
    }

    /// <summary>نوبت‌های یک روز مشخص (مدیر و پرسنل)</summary>
    [Authorize(Roles = "Admin,Personnel")]
    [HttpGet("by-date")]
    public ActionResult<List<Tbl_Reservation>> GetByDate([FromQuery] DateTime date)
        => Ok(_reservations.GetByDate(date));

    /// <summary>پیگیری رزرو با کد TC سیستمی (بند ۲۰ سند)</summary>
    [AllowAnonymous]
    [HttpGet("by-tracking/{trackingCode}")]
    public ActionResult<Tbl_Reservation> GetByTracking(string trackingCode)
    {
        var item = _reservations.GetByTrackingCode(trackingCode);
        return item is null ? NotFound(new ApiResult { Message = "نوبتی با این کد رهگیری یافت نشد" }) : Ok(item);
    }

    /// <summary>جزئیات یک نوبت</summary>
    [Authorize]
    [HttpGet("{tc:guid}")]
    public ActionResult<Tbl_Reservation> Get(Guid tc)
    {
        var item = _reservations.GetReservationByTC(tc);
        return item is null ? NotFound(new ApiResult { Message = "نوبت یافت نشد" }) : Ok(item);
    }

    /// <summary>ثبت نوبت آنلاین — همراه با اعتبارسنجی قیمت متغیر (بند ۸)</summary>
    [AllowAnonymous]
    [HttpPost]
    public ActionResult<Tbl_Reservation> Create([FromBody] Tbl_Reservation reservation)
    {
        if (string.IsNullOrWhiteSpace(reservation.CustomerName) ||
            string.IsNullOrWhiteSpace(reservation.MobileNumber) ||
            string.IsNullOrWhiteSpace(reservation.ServiceName))
            return BadRequest(new ApiResult { Message = "نام، شماره موبایل و خدمت الزامی است" });

        if (reservation.Price > 0 && !reservation.VariablePriceAgreed)
            return BadRequest(new ApiResult { Message = "تأیید شرایط قیمت متغیر قبل از ثبت نوبت الزامی است." });

        if (User.Identity?.IsAuthenticated == true && CurrentTc != Guid.Empty && IsInRole("Customer"))
            reservation.CustomerTC = CurrentTc;

        var saved = _reservations.AddReservation(reservation);
        return saved is null
            ? StatusCode(500, new ApiResult { Message = "ثبت نوبت ناموفق بود" })
            : Ok(saved);
    }

    /// <summary>ثبت نوبت حضوری یا تلفنی توسط ادمین/پرسنل (بند ۱۴ سند)</summary>
    [Authorize(Roles = "Admin,Personnel")]
    [HttpPost("in-person")]
    public ActionResult<Tbl_Reservation> CreateInPerson([FromBody] Tbl_Reservation reservation)
    {
        reservation.ReservationType = ReservationType.InPerson;
        reservation.RegisteredBy = User.FindFirstValue(ClaimTypes.Name) ?? "پرسنل سالن";
        reservation.VariablePriceAgreed = true;

        var saved = _reservations.AddReservation(reservation);
        return saved is null
            ? StatusCode(500, new ApiResult { Message = "ثبت نوبت حضوری ناموفق بود" })
            : Ok(saved);
    }

    /// <summary>شروع پرداخت و هدایت به درگاه زرین‌پال (محاسبه مبالغ سمت سرور - بند ۹ و ۱۰)</summary>
    [AllowAnonymous]
    [HttpPost("pay/request")]
    public ActionResult<PaymentRequestResult> RequestPayment([FromBody] PaymentStartRequest req)
    {
        var rsv = _reservations.GetReservationByTC(req.ReservationTC);
        if (rsv is null) return NotFound(new PaymentRequestResult { Message = "نوبت یافت نشد" });

        // محاسبه دقیق سمت سرور: قیمت خدمت منهای تخفیف
        decimal discount = 0;
        if (!string.IsNullOrWhiteSpace(req.DiscountCode))
        {
            var disc = _db.Tbl_Discount.FirstOrDefault(d => d.Code == req.DiscountCode && !d.IsDelete && d.IsActive);
            if (disc is not null && (disc.ExpireDate == null || disc.ExpireDate > DateTime.Now))
            {
                discount = Math.Min(disc.MaxDiscount > 0 ? disc.MaxDiscount : decimal.MaxValue, rsv.Price * disc.Percent / 100m);
            }
        }

        var payable = Math.Max(0, rsv.Price - discount);
        rsv.DiscountCode = req.DiscountCode;
        rsv.DiscountAmount = discount;
        rsv.PayableAmount = payable;
        rsv.PaymentStatus = PaymentStatus.RedirectedToGateway;
        _reservations.EditReservation(rsv);

        // تولید Authority شبیه‌سازی زرین‌پال با Idempotency Key
        var authority = $"ZP-{Guid.NewGuid():N}";
        var transaction = new Tbl_PaymentTransaction
        {
            Tc = Guid.NewGuid(),
            ReservationTC = rsv.Tc,
            TrackingCode = rsv.TrackingCode,
            Amount = payable,
            GatewayName = "ZarinPal",
            Authority = authority,
            Status = PaymentStatus.RedirectedToGateway,
            IdempotencyKey = req.IdempotencyKey ?? Guid.NewGuid().ToString("N"),
            IsActive = true,
            RegisterData = DateTime.Now
        };
        _db.Tbl_PaymentTransaction.Add(transaction);
        _db.SaveChanges();

        return Ok(new PaymentRequestResult
        {
            Success = true,
            Authority = authority,
            PayableAmount = payable,
            TrackingCode = rsv.TrackingCode,
            PaymentUrl = $"/reserve/verify?authority={authority}&tc={rsv.Tc}"
        });
    }

    /// <summary>تأیید بازگشت از درگاه پرداخت زرین‌پال (بند ۹ و ۱۰)</summary>
    [AllowAnonymous]
    [HttpPost("pay/verify")]
    public ActionResult<PaymentVerifyResult> VerifyPayment([FromBody] PaymentVerifyRequest req)
    {
        var rsv = _reservations.GetReservationByTC(req.ReservationTC);
        if (rsv is null) return NotFound(new PaymentVerifyResult { Message = "رزرو یافت نشد" });

        var tx = _db.Tbl_PaymentTransaction.FirstOrDefault(t => t.ReservationTC == req.ReservationTC && t.Authority == req.Authority && !t.IsDelete);
        if (tx is null)
        {
            // بازیابی نوبت در صورت قطعی یا ثبت تراکنش جدید
            tx = new Tbl_PaymentTransaction
            {
                Tc = Guid.NewGuid(),
                ReservationTC = rsv.Tc,
                TrackingCode = rsv.TrackingCode,
                Amount = rsv.PayableAmount,
                Authority = req.Authority,
                IsActive = true,
                RegisterData = DateTime.Now
            };
            _db.Tbl_PaymentTransaction.Add(tx);
        }

        if (req.Status == "OK" || req.SimulateSuccess)
        {
            var refId = $"REF-{DateTime.Now:yyMMddHHmmss}-{new Random().Next(1000, 9999)}";
            tx.RefId = refId;
            tx.Status = PaymentStatus.Paid;
            tx.StatusDescription = "پرداخت با موفقیت انجام شد";
            tx.VerifiedAt = DateTime.Now;

            _reservations.UpdatePaymentStatus(rsv.Tc, PaymentStatus.Paid, tx.Amount, refId);
            _db.SaveChanges();

            return Ok(new PaymentVerifyResult
            {
                Success = true,
                Message = "پرداخت و ثبت قطعی رزرو با موفقیت انجام شد.",
                RefId = refId,
                TrackingCode = rsv.TrackingCode,
                Amount = tx.Amount
            });
        }
        else
        {
            tx.Status = PaymentStatus.Failed;
            tx.StatusDescription = "تراکنش توسط کاربر لغو شد یا درگاه بانک پاسخ ناموفق داد.";
            _reservations.UpdatePaymentStatus(rsv.Tc, PaymentStatus.Failed, 0);
            _db.SaveChanges();

            return Ok(new PaymentVerifyResult
            {
                Success = false,
                Message = "پرداخت ناموفق بود یا توسط کاربر لغو شد.",
                TrackingCode = rsv.TrackingCode
            });
        }
    }

    /// <summary>لغو نوبت توسط ادمین به همراه محاسبه و ثبت استرداد وجه (بند ۱۵ سند)</summary>
    [Authorize(Roles = "Admin")]
    [HttpPost("{tc:guid}/refund")]
    public ActionResult<ApiResult> CancelWithRefund(Guid tc, [FromBody] RefundRequest req)
    {
        var adminName = User.FindFirstValue(ClaimTypes.Name) ?? "مدیر سالن";
        var ok = _reservations.CancelWithRefund(tc, req.RefundAmount, adminName, req.RefundReference ?? $"REFUND-{DateTime.Now:MMddHHmm}", req.CancelReason ?? "لغو توسط مدیریت سالن");
        return ok
            ? Ok(new ApiResult { Success = true, Message = $"رزرو با موفقیت لغو شد و مبلغ {req.RefundAmount:#,0} تومان استرداد ثبت شد." })
            : NotFound(new ApiResult { Message = "نوبت یافت نشد" });
    }

    /// <summary>تغییر وضعیت نوبت (مدیر و پرسنل)</summary>
    [Authorize(Roles = "Admin,Personnel")]
    [HttpPatch("{tc:guid}/status")]
    public ActionResult<ApiResult> ChangeStatus(Guid tc, [FromBody] ChangeStatusRequest request)
        => _reservations.ChangeStatus(tc, request.Status, request.CancelReason)
            ? Ok(new ApiResult { Success = true, Message = "وضعیت نوبت به‌روزرسانی شد" })
            : NotFound(new ApiResult { Message = "نوبت یافت نشد" });

    /// <summary>لغو نوبت توسط مشتری</summary>
    [Authorize]
    [HttpPatch("{tc:guid}/cancel")]
    public ActionResult<ApiResult> Cancel(Guid tc, [FromBody] ChangeStatusRequest? request)
    {
        var item = _reservations.GetReservationByTC(tc);
        if (item is null) return NotFound(new ApiResult { Message = "نوبت یافت نشد" });

        if (!IsInRole("Admin") && !IsInRole("Personnel") && item.CustomerTC != CurrentTc)
            return Forbid();

        return _reservations.ChangeStatus(tc, ReservationStatus.Canceled, request?.CancelReason ?? "لغو توسط کاربر")
            ? Ok(new ApiResult { Success = true, Message = "نوبت لغو شد" })
            : StatusCode(500, new ApiResult { Message = "لغو نوبت ناموفق بود" });
    }

    /// <summary>ویرایش نوبت (مدیر)</summary>
    [Authorize(Roles = "Admin")]
    [HttpPut("{tc:guid}")]
    public ActionResult<ApiResult> Update(Guid tc, [FromBody] Tbl_Reservation reservation)
    {
        reservation.Tc = tc;
        return _reservations.EditReservation(reservation)
            ? Ok(new ApiResult { Success = true, Message = "نوبت ویرایش شد" })
            : NotFound(new ApiResult { Message = "نوبت یافت نشد" });
    }

    /// <summary>حذف نوبت (مدیر)</summary>
    [Authorize(Roles = "Admin")]
    [HttpDelete("{tc:guid}")]
    public ActionResult<ApiResult> Delete(Guid tc)
        => _reservations.DeleteReservation(tc)
            ? Ok(new ApiResult { Success = true, Message = "نوبت حذف شد" })
            : NotFound(new ApiResult { Message = "نوبت یافت نشد" });
}

public class ChangeStatusRequest
{
    public ReservationStatus Status { get; set; }
    public string? CancelReason { get; set; }
}

public class RefundRequest
{
    public decimal RefundAmount { get; set; }
    public string? RefundReference { get; set; }
    public string? CancelReason { get; set; }
}

public class PaymentStartRequest
{
    public Guid ReservationTC { get; set; }
    public string? DiscountCode { get; set; }
    public string? IdempotencyKey { get; set; }
}

public class PaymentRequestResult
{
    public bool Success { get; set; }
    public string? Message { get; set; }
    public string? Authority { get; set; }
    public decimal PayableAmount { get; set; }
    public string? TrackingCode { get; set; }
    public string? PaymentUrl { get; set; }
}

public class PaymentVerifyRequest
{
    public Guid ReservationTC { get; set; }
    public string Authority { get; set; } = string.Empty;
    public string Status { get; set; } = "OK";
    public bool SimulateSuccess { get; set; } = true;
}

public class PaymentVerifyResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public string? RefId { get; set; }
    public string? TrackingCode { get; set; }
    public decimal Amount { get; set; }
}

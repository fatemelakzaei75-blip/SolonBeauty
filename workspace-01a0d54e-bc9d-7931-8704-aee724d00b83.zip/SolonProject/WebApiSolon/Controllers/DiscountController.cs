using System;
using System.Linq;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiSolon.Models;

namespace WebApiSolon.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DiscountController : ControllerBase
{
    private readonly DatabaseContext _db;
    public DiscountController(DatabaseContext db) => _db = db;

    /// <summary>اعتبارسنجی کد تخفیف در سمت سرور (بند ۸ و ۹)</summary>
    [HttpGet("validate/{code}")]
    public ActionResult<DiscountValidationResult> Validate(string code, [FromQuery] decimal amount)
    {
        if (string.IsNullOrWhiteSpace(code))
            return BadRequest(new DiscountValidationResult { Valid = false, Message = "کد تخفیف را وارد کنید." });

        code = code.Trim().ToUpperInvariant();
        var disc = _db.Tbl_Discount.FirstOrDefault(d => d.Code.ToUpper() == code && !d.IsDelete && d.IsActive);

        // تخفیف‌های پیش‌فرض دمو
        if (disc is null)
        {
            if (code == "HADIS20")
            {
                var dAmt = Math.Min(300_000m, amount * 0.20m);
                return Ok(new DiscountValidationResult
                {
                    Valid = true,
                    Code = code,
                    Title = "۲۰٪ تخفیف افتتاحیه آنلاین",
                    Percent = 20,
                    DiscountAmount = dAmt,
                    FinalAmount = Math.Max(0, amount - dAmt),
                    Message = "کد تخفیف ۲۰٪ با موفقیت اعمال شد."
                });
            }
            if (code == "BEAUTY10")
            {
                var dAmt = Math.Min(150_000m, amount * 0.10m);
                return Ok(new DiscountValidationResult
                {
                    Valid = true,
                    Code = code,
                    Title = "۱۰٪ تخفیف همراهان سالن",
                    Percent = 10,
                    DiscountAmount = dAmt,
                    FinalAmount = Math.Max(0, amount - dAmt),
                    Message = "کد تخفیف ۱۰٪ با موفقیت اعمال شد."
                });
            }
            return NotFound(new DiscountValidationResult { Valid = false, Message = "کد تخفیف وارد شده نامعتبر یا منقضی شده است." });
        }

        if (disc.ExpireDate.HasValue && disc.ExpireDate.Value < DateTime.Now)
            return BadRequest(new DiscountValidationResult { Valid = false, Message = "مهلت استفاده از این کد تخفیف به پایان رسیده است." });

        if (disc.MinPurchase > 0 && amount < disc.MinPurchase)
            return BadRequest(new DiscountValidationResult { Valid = false, Message = $"حداقل مبلغ برای این کد تخفیف {disc.MinPurchase:#,0} تومان است." });

        decimal discountValue = amount * disc.Percent / 100m;
        if (disc.MaxDiscount > 0 && discountValue > disc.MaxDiscount) discountValue = disc.MaxDiscount;

        return Ok(new DiscountValidationResult
        {
            Valid = true,
            Code = disc.Code,
            Title = disc.Title,
            Percent = disc.Percent,
            DiscountAmount = discountValue,
            FinalAmount = Math.Max(0, amount - discountValue),
            Message = $"کد تخفیف {disc.Percent}٪ با موفقیت اعمال شد."
        });
    }

    [Authorize(Roles = "Admin")]
    [HttpGet]
    public ActionResult GetList() => Ok(_db.Tbl_Discount.Where(x => !x.IsDelete).ToList());

    [Authorize(Roles = "Admin")]
    [HttpPost]
    public ActionResult Create([FromBody] Tbl_Discount disc)
    {
        disc.Tc = Guid.NewGuid();
        disc.IsActive = true;
        disc.RegisterData = DateTime.Now;
        _db.Tbl_Discount.Add(disc);
        _db.SaveChanges();
        return Ok(disc);
    }
}

public class DiscountValidationResult
{
    public bool Valid { get; set; }
    public string Message { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public int Percent { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal FinalAmount { get; set; }
}

using System;
using System.Linq;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiSolon.Models;

namespace WebApiSolon.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CommentController : ControllerBase
{
    private readonly DatabaseContext _db;
    public CommentController(DatabaseContext db) => _db = db;

    [HttpGet]
    public ActionResult GetApproved()
        => Ok(_db.Tbl_Comment.Where(c => !c.IsDelete && c.IsApproved).OrderByDescending(c => c.RegisterData).ToList());

    [HttpPost]
    public ActionResult Add([FromBody] Tbl_Comment comment)
    {
        if (string.IsNullOrWhiteSpace(comment.CustomerName) || string.IsNullOrWhiteSpace(comment.CommentText))
            return BadRequest(new ApiResult { Message = "نام و متن نظر الزامی است." });

        comment.Tc = Guid.NewGuid();
        comment.IsActive = true;
        comment.IsApproved = true;
        comment.RegisterData = DateTime.Now;
        _db.Tbl_Comment.Add(comment);
        _db.SaveChanges();
        return Ok(comment);
    }
}

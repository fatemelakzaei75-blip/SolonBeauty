using System;
using System.Collections.Generic;
using System.Linq;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApiSolon.Controllers;

[Authorize(Roles = "Admin")]
[ApiController]
[Route("api/[controller]")]
public class ReportController : ControllerBase
{
    private readonly DatabaseContext _db;
    public ReportController(DatabaseContext db) => _db = db;

    /// <summary>آمار و شاخص‌های کلیدی عملکرد (KPI - بند ۱۸ سند)</summary>
    [HttpGet("kpi")]
    public ActionResult<DashboardKpiDto> GetKpi()
    {
        var today = DateTime.Today;
        var rsvList = _db.Tbl_Reservation.Where(r => !r.IsDelete).ToList();

        var totalCustomers = _db.Tbl_Customer.Count(c => !c.IsDelete);
        var todayReservations = rsvList.Count(r => r.ReserveDate.Date == today);
        var pendingReservations = rsvList.Count(r => r.Status == ReservationStatus.PendingPayment);
        var completedReservations = rsvList.Count(r => r.Status == ReservationStatus.Confirmed || r.Status == ReservationStatus.PaymentSuccessful || r.Status == ReservationStatus.Done);
        var canceledReservations = rsvList.Count(r => r.Status == ReservationStatus.Canceled);
        var totalIncome = rsvList.Where(r => r.PaymentStatus == PaymentStatus.Paid).Sum(r => r.PaidAmount > 0 ? r.PaidAmount : r.PayableAmount);
        var totalRefunds = rsvList.Sum(r => r.RefundAmount);
        var netIncome = Math.Max(0, totalIncome - totalRefunds);
        var activePersonnel = _db.Tbl_Personal.Count(p => !p.IsDelete && p.IsActive);
        var activeServices = _db.Tbl_SalonSerice.Count(s => !s.IsDelete && s.IsActive);

        return Ok(new DashboardKpiDto
        {
            TotalCustomers = totalCustomers,
            TodayReservations = todayReservations,
            PendingReservations = pendingReservations,
            CompletedReservations = completedReservations,
            CanceledReservations = canceledReservations,
            TotalIncome = totalIncome,
            TotalRefunds = totalRefunds,
            NetIncome = netIncome,
            ActivePersonnel = activePersonnel,
            ActiveServices = activeServices
        });
    }

    /// <summary>گزارش‌های دوره‌ای (روزانه، هفتگی، ماهانه، سالانه - بند ۱۸ سند)</summary>
    [HttpGet("summary")]
    public ActionResult GetSummary([FromQuery] string period = "monthly")
    {
        var rsvList = _db.Tbl_Reservation.Where(r => !r.IsDelete).ToList();

        // گروه‌بندی ساده بر اساس خدمت
        var serviceBreakdown = rsvList
            .GroupBy(r => r.ServiceName)
            .Select(g => new { ServiceName = g.Key, Count = g.Count(), Total = g.Sum(x => x.PaidAmount > 0 ? x.PaidAmount : x.PayableAmount) })
            .OrderByDescending(x => x.Count)
            .Take(5)
            .ToList();

        return Ok(new
        {
            Period = period,
            TopServices = serviceBreakdown,
            TotalCount = rsvList.Count,
            TotalRevenue = rsvList.Sum(x => x.PaidAmount)
        });
    }
}

public class DashboardKpiDto
{
    public int TotalCustomers { get; set; }
    public int TodayReservations { get; set; }
    public int PendingReservations { get; set; }
    public int CompletedReservations { get; set; }
    public int CanceledReservations { get; set; }
    public decimal TotalIncome { get; set; }
    public decimal TotalRefunds { get; set; }
    public decimal NetIncome { get; set; }
    public int ActivePersonnel { get; set; }
    public int ActiveServices { get; set; }
}

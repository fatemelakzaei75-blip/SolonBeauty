using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiSolon.Models;
using WebApiSolon.Services;

namespace WebApiSolon.Controllers;

/// <summary>آپلود تصاویر نمونه کار (ذخیره در ریشه API با نام هش شده)</summary>
[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Admin,Personnel")]
public class UploadController : ControllerBase
{
    private readonly FileStorageService _storage;
    public UploadController(FileStorageService storage) => _storage = storage;

    /// <summary>آپلود یک تصویر — بخش پیش فرض: portfolio</summary>
    [HttpPost("image")]
    [RequestSizeLimit(6 * 1024 * 1024)]
    public async Task<ActionResult<ApiResult>> UploadImage(IFormFile file, [FromQuery] string section = "portfolio")
    {
        var (ok, message) = _storage.Validate(file);
        if (!ok) return BadRequest(new ApiResult { Message = message });

        var stored = await _storage.SaveAsync(file, section, HttpContext.RequestAborted);

        return Ok(new ApiResult
        {
            Success = true,
            Message = stored.AlreadyExisted ? "این تصویر قبلاً آپلود شده بود و همان نسخه استفاده شد" : "تصویر با موفقیت آپلود شد",
            Data = new
            {
                url = stored.RelativeUrl,
                fileName = stored.FileName,
                hash = stored.Hash,
                size = stored.Size,
                duplicate = stored.AlreadyExisted
            }
        });
    }

    /// <summary>آپلود چند تصویر هم زمان</summary>
    [HttpPost("images")]
    [RequestSizeLimit(30 * 1024 * 1024)]
    public async Task<ActionResult<ApiResult>> UploadImages([FromForm] IFormFileCollection files, [FromQuery] string section = "portfolio")
    {
        var results = new List<object>();
        var errors = new List<string>();

        foreach (var file in files)
        {
            var (ok, message) = _storage.Validate(file);
            if (!ok) { errors.Add($"{file.FileName}: {message}"); continue; }

            var stored = await _storage.SaveAsync(file, section, HttpContext.RequestAborted);
            results.Add(new { url = stored.RelativeUrl, hash = stored.Hash, duplicate = stored.AlreadyExisted });
        }

        return Ok(new ApiResult
        {
            Success = errors.Count == 0,
            Message = errors.Count == 0 ? $"{results.Count} تصویر آپلود شد" : string.Join(" | ", errors),
            Data = results
        });
    }

    /// <summary>فهرست تصاویر آپلود شده یک بخش</summary>
    [HttpGet("list")]
    public ActionResult<ApiResult> List([FromQuery] string section = "portfolio")
        => Ok(new ApiResult { Success = true, Data = _storage.List(section) });

    /// <summary>حذف یک تصویر آپلود شده (فقط مدیر)</summary>
    [HttpDelete]
    [Authorize(Roles = "Admin")]
    public ActionResult<ApiResult> Delete([FromQuery] string url)
        => _storage.Delete(url)
            ? Ok(new ApiResult { Success = true, Message = "تصویر حذف شد" })
            : NotFound(new ApiResult { Message = "تصویر یافت نشد" });
}

using BlazorAppSolon;
using BlazorAppSolon.Auth;
using BlazorAppSolon.Data;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using System.Net.Http.Json;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });

// ---------- احراز هویت JWT ----------
builder.Services.AddScoped<JwtAuthenticationStateProvider>();
builder.Services.AddScoped<AuthenticationStateProvider>(sp => sp.GetRequiredService<JwtAuthenticationStateProvider>());
builder.Services.AddScoped<AuthService>();
builder.Services.AddAuthorizationCore();

// ---------- منبع داده پنل ها ----------
// ApiDataStore ابتدا از WebApi می خواند و در نبود سرویس به داده نمونه بازمی گردد
builder.Services.AddSingleton<MockDb>();
builder.Services.AddScoped<IDataStore, ApiDataStore>();
builder.Services.AddScoped<FavoriteService>();
builder.Services.AddScoped<UploadService>();
builder.Services.AddScoped<ReservationClient>();

// آدرس WebApi از wwwroot/appsettings.json خوانده می شود
using (var http = new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) })
{
    try
    {
        var cfg = await http.GetFromJsonAsync<Dictionary<string, string>>("appsettings.json");
        if (cfg is not null && cfg.TryGetValue("ApiBaseUrl", out var apiBase))
            AuthService.ApiBase = apiBase.TrimEnd('/');
    }
    catch { /* تنظیمات اختیاری است */ }
}

await builder.Build().RunAsync();

using System;
using System.Collections.Generic;
using System.Linq;
using DataCore.Interfaces;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.EntityFrameworkCore;

namespace DataCore.Services;

/// <summary>
/// ثبت و مدیریت نوبت‌ها روی جدول Tbl_Reservation (بندهای ۸، ۹، ۱۰، ۱۴ و ۱۵ سند)
/// همراه با تولید خودکار TC (بند ۲۰) و ثبت اعلانات به مدیر و پرسنل (بند ۱۷)
/// </summary>
public class ReservationService : BaseRepository<Tbl_Reservation>, IReservationService
{
    public ReservationService(DatabaseContext db) : base(db) { }

    public List<Tbl_Reservation> GetReservations()
        => Query.AsNoTracking().OrderByDescending(r => r.ReserveDate).ThenBy(r => r.ReserveTime).ToList();

    public Tbl_Reservation? GetReservationByTC(Guid tc) => GetByTc(tc);

    public Tbl_Reservation? GetByTrackingCode(string trackingCode)
        => Query.AsNoTracking().FirstOrDefault(r => r.TrackingCode == trackingCode);

    public List<Tbl_Reservation> GetByCustomerTC(Guid customerTC)
        => Query.AsNoTracking().Where(r => r.CustomerTC == customerTC)
                .OrderByDescending(r => r.ReserveDate).ThenBy(r => r.ReserveTime).ToList();

    public List<Tbl_Reservation> GetByPersonalTC(Guid personalTC)
        => Query.AsNoTracking().Where(r => r.PersonalTC == personalTC)
                .OrderBy(r => r.ReserveDate).ThenBy(r => r.ReserveTime).ToList();

    public List<Tbl_Reservation> GetByDate(DateTime date)
        => Query.AsNoTracking().Where(r => r.ReserveDate.Date == date.Date)
                .OrderBy(r => r.ReserveTime).ToList();

    /// <summary>
    /// ثبت نوبت با تولید خودکار کد پیگیری (TC)، اتصال به مشتری و ایجاد اعلانات به مدیر و پرسنل
    /// </summary>
    public Tbl_Reservation? AddReservation(Tbl_Reservation reservation)
    {
        try
        {
            reservation.MobileNumber = NormalizeDigits(reservation.MobileNumber);

            if (reservation.CustomerTC == Guid.Empty)
                reservation.CustomerTC = EnsureCustomer(reservation.CustomerName, reservation.MobileNumber);

            reservation.Tc = reservation.Tc == Guid.Empty ? Guid.NewGuid() : reservation.Tc;

            // بند ۲۰: تولید خودکار کد پیگیری TC در سمت سرور
            if (string.IsNullOrWhiteSpace(reservation.TrackingCode))
            {
                var count = Set.Count() + 1;
                reservation.TrackingCode = $"TC-{DateTime.Now:yyMMdd}-{count:D4}";
            }

            // محاسبه مبلغ قابل پرداخت سمت سرور (بند ۹)
            if (reservation.PayableAmount <= 0)
            {
                reservation.PayableAmount = Math.Max(0, reservation.Price - reservation.DiscountAmount);
            }

            if (reservation.ReservationType == ReservationType.InPerson || reservation.ReservationType == ReservationType.Admin)
            {
                reservation.Status = ReservationStatus.Confirmed;
                reservation.PaymentStatus = PaymentStatus.Paid;
                reservation.PaidAmount = reservation.PayableAmount;
            }
            else
            {
                reservation.Status = ReservationStatus.PendingPayment;
                if (reservation.PaymentStatus == PaymentStatus.Paid)
                {
                    reservation.Status = ReservationStatus.PaymentSuccessful;
                }
            }

            reservation.IsActive = true;
            reservation.RegisterData = DateTime.Now;

            var ok = Insert(reservation);
            if (!ok) return null;

            // بند ۱۷: ارسال اعلان به کارتابل مدیر و پرسنل
            try
            {
                // اعلان به مدیر
                Db.Tbl_Notification.Add(new Tbl_Notification
                {
                    Tc = Guid.NewGuid(),
                    TargetRole = "Admin",
                    Title = "رزرو جدید ثبت شد",
                    Message = $"رزرو جدید برای خدمت «{reservation.ServiceName}» توسط {reservation.CustomerName} ({reservation.TrackingCode})",
                    CreatedAt = DateTime.Now,
                    IsActive = true,
                    RegisterData = DateTime.Now,
                    Link = $"/panel/admin/entity/reservation?tc={reservation.Tc}"
                });

                // اعلان به پرسنل
                if (reservation.PersonalTC != Guid.Empty || !string.IsNullOrWhiteSpace(reservation.PersonalName))
                {
                    Db.Tbl_Notification.Add(new Tbl_Notification
                    {
                        Tc = Guid.NewGuid(),
                        TargetRole = "Personnel",
                        TargetUserTC = reservation.PersonalTC != Guid.Empty ? reservation.PersonalTC : null,
                        Title = "نوبت جدید برای شما",
                        Message = $"برای شما یک نوبت جدید برای خدمت «{reservation.ServiceName}» در تاریخ {reservation.ReserveDate:yyyy/MM/dd} ساعت {reservation.ReserveTime:hh\\:mm} ثبت شد.",
                        CreatedAt = DateTime.Now,
                        IsActive = true,
                        RegisterData = DateTime.Now
                    });
                }
                Db.SaveChanges();
            }
            catch { /* خطا در ثبت اعلان مانع از تکمیل رزرو نمی‌شود */ }

            return reservation;
        }
        catch { return null; }
    }

    public bool EditReservation(Tbl_Reservation reservation) => Modify(reservation);

    public bool ChangeStatus(Guid tc, ReservationStatus status, string? cancelReason = null)
    {
        try
        {
            var current = Set.FirstOrDefault(r => r.Tc == tc && !r.IsDelete);
            if (current is null) return false;

            current.Status = status;
            if (status == ReservationStatus.Confirmed) current.ConfirmDate = DateTime.Now;
            if (status == ReservationStatus.Canceled) current.CancelReason = cancelReason;

            return Db.SaveChanges() > 0;
        }
        catch { return false; }
    }

    /// <summary>لغو رزرو به همراه ثبت جزئیات استرداد وجه (بند ۱۵ سند)</summary>
    public bool CancelWithRefund(Guid tc, decimal refundAmount, string refundBy, string refundRef, string cancelReason)
    {
        try
        {
            var current = Set.FirstOrDefault(r => r.Tc == tc && !r.IsDelete);
            if (current is null) return false;

            current.Status = ReservationStatus.Canceled;
            current.CancelReason = cancelReason;
            current.RefundAmount = refundAmount;
            current.RefundStatus = refundAmount > 0 ? "استرداد شده" : "بدون استرداد";
            current.RefundDate = DateTime.Now;
            current.RefundBy = refundBy;
            current.RefundReference = refundRef;

            return Db.SaveChanges() > 0;
        }
        catch { return false; }
    }

    /// <summary>به‌روزرسانی وضعیت پرداخت با پشتیبانی از بازگشت از درگاه (بند ۹ و ۱۰)</summary>
    public bool UpdatePaymentStatus(Guid tc, PaymentStatus status, decimal paidAmount, string? refId = null)
    {
        try
        {
            var current = Set.FirstOrDefault(r => r.Tc == tc && !r.IsDelete);
            if (current is null) return false;

            current.PaymentStatus = status;
            if (status == PaymentStatus.Paid)
            {
                current.PaidAmount = paidAmount;
                current.Status = ReservationStatus.PaymentSuccessful;
                current.ConfirmDate = DateTime.Now;
            }
            else if (status == PaymentStatus.Failed || status == PaymentStatus.Canceled)
            {
                current.Status = ReservationStatus.Canceled;
            }

            return Db.SaveChanges() > 0;
        }
        catch { return false; }
    }

    public bool DeleteReservation(Guid tc) => SoftDelete(tc);

    private Guid EnsureCustomer(string fullName, string mobileNumber)
    {
        var mobile = Db.Tbl_Mobile.FirstOrDefault(m => m.MobileNumber == mobileNumber && !m.IsDelete);
        if (mobile is null)
        {
            mobile = new Tbl_Mobile
            {
                Tc = Guid.NewGuid(), MobileNumber = mobileNumber, TcPersonal = string.Empty,
                IsActive = true, RegisterData = DateTime.Now
            };
            Db.Tbl_Mobile.Add(mobile);
            Db.SaveChanges();
        }

        var customer = Db.Tbl_Customer.FirstOrDefault(c => c.Tc == mobile.Tc && !c.IsDelete);
        if (customer is null)
        {
            customer = new Tbl_Customer
            {
                Tc = mobile.Tc,
                FullName = string.IsNullOrWhiteSpace(fullName) ? "مشتری سالن" : fullName,
                IsActive = true, RegisterData = DateTime.Now
            };
            Db.Tbl_Customer.Add(customer);
            Db.SaveChanges();
        }

        return customer.Tc;
    }

    private static string NormalizeDigits(string? input)
    {
        if (string.IsNullOrWhiteSpace(input)) return string.Empty;
        const string fa = "۰۱۲۳۴۵۶۷۸۹", ar = "٠١٢٣٤٥٦٧٨٩";
        var sb = new System.Text.StringBuilder();
        foreach (var ch in input.Trim())
        {
            var i = fa.IndexOf(ch); var j = ar.IndexOf(ch);
            if (i >= 0) sb.Append((char)('0' + i));
            else if (j >= 0) sb.Append((char)('0' + j));
            else if (char.IsWhiteSpace(ch) || ch is '-' or '_') continue;
            else sb.Append(ch);
        }
        return sb.ToString();
    }
}

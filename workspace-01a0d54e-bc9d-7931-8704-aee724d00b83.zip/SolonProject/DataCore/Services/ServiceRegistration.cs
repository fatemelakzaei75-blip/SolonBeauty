using DataCore.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace DataCore.Services;

/// <summary>ثبت تمام سرویس های لایه DataCore در DI</summary>
public static class ServiceRegistration
{
    public static IServiceCollection AddDataCoreServices(this IServiceCollection services)
    {
        services.AddScoped<ISalonService, SalonService>();
        services.AddScoped<ICategoryService, CategoryService>();
        services.AddScoped<ISalonServiceService, SalonServiceService>();
        services.AddScoped<ISocialService, SocialService>();
        services.AddScoped<INewsDayService, NewsDayService>();

        services.AddScoped<ICustomerService, CustomerService>();
        services.AddScoped<IPersonalService, PersonalService>();
        services.AddScoped<IMobileService, MobileService>();
        services.AddScoped<IConfirmService, ConfirmService>();

        services.AddScoped<IRoleService, RoleService>();
        services.AddScoped<IPermissionService, PermissionService>();
        services.AddScoped<IRolePermissionService, RolePermissionService>();
        services.AddScoped<IUserRoleService, UserRoleService>();
        services.AddScoped<UserRoleService>();

        services.AddScoped<IReservationService, ReservationService>();

        services.AddScoped<ICategoryPortfolioService, CategoryPortfolioService>();
        services.AddScoped<IPortfolioService, PortfolioService>();
        services.AddScoped<ILikeService, LikeService>();
        services.AddSingleton<IPortfolioViewService, PortfolioViewService>();

        return services;
    }
}

using DataCore.Interfaces;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.EntityFrameworkCore;

namespace DataCore.Services;

/// <summary>مشتریان</summary>
public class CustomerService : BaseRepository<Tbl_Customer>, ICustomerService
{
    public CustomerService(DatabaseContext db) : base(db) { }

    public List<Tbl_Customer> GetCustomers() => GetAll();
    public Tbl_Customer GetCustomerByToken(Guid token) => GetByTc(token)!;
    public bool IsCustomerExists(Guid token) => Query.Any(x => x.Tc == token);
    public List<Tbl_Customer> SearchCustomers(string search)
        => Query.AsNoTracking().Where(x => x.FullName.Contains(search) || (x.CodeMoaref ?? "").Contains(search)).ToList();
    public bool AddCustomer(Tbl_Customer customer) => Insert(customer);
    public bool EditCustomer(Tbl_Customer customer) => Modify(customer);
    public bool DeleteCustomer(string token) => SoftDelete(token);
}

/// <summary>پرسنل</summary>
public class PersonalService : BaseRepository<Tbl_Personal>, IPersonalService
{
    public PersonalService(DatabaseContext db) : base(db) { }

    public List<Tbl_Personal> GetPersonals() => GetAll();
    public Tbl_Personal GetPersonalByToken(string token) => GetByTc(token)!;
    public bool IsPersonalExists(string token) => Guid.TryParse(token, out var g) && Query.Any(x => x.Tc == g);
    public List<Tbl_Personal> SearchPersonals(string search)
        => Guid.TryParse(search, out var g)
            ? Query.AsNoTracking().Where(x => x.TC_Service == g || x.salon_Tc == g).ToList()
            : GetAll();
    public bool AddPersonal(Tbl_Personal personal) => Insert(personal);
    public bool EditPersonal(Tbl_Personal personal) => Modify(personal);
    public bool DeletePersonal(string token) => SoftDelete(token);
}

/// <summary>شماره موبایل کاربران</summary>
public class MobileService : BaseRepository<Tbl_Mobile>, IMobileService
{
    public MobileService(DatabaseContext db) : base(db) { }

    public bool IsMobileExists(string mobileNumber) => Query.Any(x => x.MobileNumber == mobileNumber);

    public Tbl_Mobile Create(string mobileNumber)
    {
        var existing = Query.FirstOrDefault(x => x.MobileNumber == mobileNumber);
        if (existing is not null) return existing;

        var mobile = new Tbl_Mobile
        {
            Tc = Guid.NewGuid(),
            MobileNumber = mobileNumber,
            TcPersonal = string.Empty,
            IsActive = true,
            RegisterData = DateTime.Now
        };
        Insert(mobile);
        return mobile;
    }
}

/// <summary>کد تأیید ورود (OTP)</summary>
public class ConfirmService : BaseRepository<Tbl_Confirm>, IConfirmService
{
    private readonly IMobileService _mobileService;

    /// <summary>کد ثابت محیط توسعه — در محیط واقعی باید با پنل پیامک جایگزین شود</summary>
    public const string DevCode = "12345";

    public ConfirmService(DatabaseContext db, IMobileService mobileService) : base(db)
        => _mobileService = mobileService;

    public void SendCode(string mobileNumber)
    {
        var mobile = _mobileService.Create(mobileNumber);
        var code = DevCode;

        Insert(new Tbl_Confirm
        {
            Tc = Guid.NewGuid(),
            Tc_Mobile = mobile.Tc,
            Code = code,
            IpUser = "-",
            SentDate = DateTime.Now,
            SentCount = 1,
            IsActive = true
        });
        // TODO: ارسال پیامک واقعی
    }

    public bool VerifyCode(string mobileNumber, string code)
    {
        var mobile = Db.Tbl_Mobile.FirstOrDefault(m => m.MobileNumber == mobileNumber && !m.IsDelete);
        if (mobile is null) return false;

        var confirm = Set.Where(c => c.Tc_Mobile == mobile.Tc && !c.IsDelete)
                         .OrderByDescending(c => c.SentDate)
                         .FirstOrDefault();
        if (confirm is null) return false;

        confirm.TryCount++;
        if (confirm.Code != code) { Db.SaveChanges(); return false; }

        confirm.IsConfirmed = true;
        confirm.ConfirmDate = DateTime.Now;
        Db.SaveChanges();
        return true;
    }
}

/// <summary>نقش ها</summary>
public class RoleService : BaseRepository<Tbl_Roles>, IRoleService
{
    public RoleService(DatabaseContext db) : base(db) { }

    public List<Tbl_Roles> GetRoles() => GetAll();
    public Tbl_Roles GetRoleById(string Tc) => GetByTc(Tc)!;
    public List<Tbl_Roles> SearchRoles(string search)
        => Query.AsNoTracking().Where(x => x.RoleName.Contains(search) || (x.Description ?? "").Contains(search)).ToList();
    public bool AddRole(Tbl_Roles role) => Insert(role);
    public bool EditRole(Tbl_Roles role) => Modify(role);
    public bool DeleteRole(string Tc) => SoftDelete(Tc);
}

/// <summary>دسترسی ها</summary>
public class PermissionService : BaseRepository<Tbl_Permission>, IPermissionService
{
    public PermissionService(DatabaseContext db) : base(db) { }

    public List<Tbl_Permission> GetPermissions() => GetAll();
    public Tbl_Permission GetPermissionByTC(string tc) => GetByTc(tc)!;
    public List<Tbl_Permission> SearchPermissions(string search)
        => Query.AsNoTracking().Where(x => x.PermissionName.Contains(search)).ToList();
    public bool AddPermission(Tbl_Permission permission) => Insert(permission);
    public bool EditPermission(Tbl_Permission permission) => Modify(permission);
    public bool DeletePermission(string tc) => SoftDelete(tc);
}

/// <summary>ارتباط نقش و دسترسی</summary>
public class RolePermissionService : BaseRepository<Tbl_RolePermission>, IRolePermissionService
{
    public RolePermissionService(DatabaseContext db) : base(db) { }

    public List<Tbl_RolePermission> GetRolePermissions() => GetAll();
    public List<Tbl_RolePermission> GetPermissionsByRoleTC(Guid roleTC)
        => Query.AsNoTracking().Where(x => x.Tc == roleTC).ToList();
    public List<Tbl_RolePermission> GetRolesByPermissionTC(Guid permissionTC)
        => Query.AsNoTracking().Where(x => x.PermissionTC == permissionTC).ToList();
    public bool AddRolePermission(Tbl_RolePermission rolePermission) => Insert(rolePermission);
    public bool EditRolePermission(Tbl_RolePermission rolePermission) => Modify(rolePermission);
    public bool DeleteRolePermission(Guid tc) => SoftDelete(tc);
}

/// <summary>نقش کاربران</summary>
public class UserRoleService : BaseRepository<Tbl_UserRole>, IUserRoleService
{
    public UserRoleService(DatabaseContext db) : base(db) { }

    public bool AddUserRole(Tbl_UserRole userRole) => Insert(userRole);
    public bool EditUserRole(Tbl_UserRole userRole) => Modify(userRole);
    public bool DeleteUserRole(string tc) => SoftDelete(tc);
    public List<Tbl_UserRole> SearchByRoleTC(string roleTc)
        => Guid.TryParse(roleTc, out var g) ? Query.AsNoTracking().Where(x => x.RoleTC == g).ToList() : new();

    /// <summary>نام نقش های یک پرسنل</summary>
    public List<string> GetRoleNamesByPersonalTc(Guid personalTc)
        => (from ur in Query
            join r in Db.Tbl_Roles on ur.RoleTC equals r.Tc
            where ur.PersonalTC == personalTc && !r.IsDelete
            select r.RoleName).ToList();
}

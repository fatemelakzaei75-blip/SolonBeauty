using System;
using System.Collections.Generic;
using DataLayer.Entity;

namespace DataCore.Interfaces
{
    /// <summary>مدیریت جامع نوبت‌های سالن (بندهای ۸، ۹، ۱۰، ۱۴ و ۱۵ سند نیازمندی‌ها)</summary>
    public interface IReservationService
    {
        List<Tbl_Reservation> GetReservations();
        Tbl_Reservation? GetReservationByTC(Guid tc);
        Tbl_Reservation? GetByTrackingCode(string trackingCode);
        List<Tbl_Reservation> GetByCustomerTC(Guid customerTC);
        List<Tbl_Reservation> GetByPersonalTC(Guid personalTC);
        List<Tbl_Reservation> GetByDate(DateTime date);

        /// <summary>ثبت نوبت (تولید خودکار TC، اعتبارسنجی مبلغ، ایجاد نوتیفیکیشن برای مدیر و پرسنل)</summary>
        Tbl_Reservation? AddReservation(Tbl_Reservation reservation);

        bool EditReservation(Tbl_Reservation reservation);
        bool ChangeStatus(Guid tc, ReservationStatus status, string? cancelReason = null);
        bool CancelWithRefund(Guid tc, decimal refundAmount, string refundBy, string refundRef, string cancelReason);
        bool UpdatePaymentStatus(Guid tc, PaymentStatus status, decimal paidAmount, string? refId = null);
        bool DeleteReservation(Guid tc);
    }
}
